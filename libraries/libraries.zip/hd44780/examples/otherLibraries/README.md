OtherLibraries
==============

This directory contains subdirectories for other (non hd44780) libraries that contain wrapper sketches for various hd44780examples sketches.

The hd44780examples directory under each subdirectory contains
library and i/o class specific wrapper sketches for various sketches under
examples/hd44780examples.
This is intended to allow easy benchmarking of the other libraries for comparison purposes.
